// Previous Button
if ($("#previous-a").attr("href") == "#"){
    $("#previous-li").remove();
}

// Next Button
if ($("#next-a").attr("href") == "#"){
    $("#next-li").remove();
}
